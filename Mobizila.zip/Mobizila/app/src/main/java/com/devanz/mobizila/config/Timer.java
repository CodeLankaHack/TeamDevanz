package com.devanz.mobizila.config;

/**
 * Created by Dilanka on 5/12/2016.
 */
public abstract class Timer extends Thread {
    Thread t;
    public abstract void method();
    @Override
    public void run() {
        try {
            Thread.sleep(1000);
//            method();
            System.out.println("Timer");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.run();
    }

    @Override
    public synchronized void start() {
        if (t==null){
            t=new Thread(this);
            t.start();
        }
        super.start();
    }
}
