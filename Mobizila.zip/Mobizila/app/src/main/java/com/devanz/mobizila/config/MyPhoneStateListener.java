package com.devanz.mobizila.config;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.lang.reflect.Method;

/**
 * Created by Stelan Briyan on 5/12/2016.
 */
public class MyPhoneStateListener extends PhoneStateListener {
    boolean smsSend;
    String number;
    Context context;

    public void setContext(Context c){
        context=c;
    }
    public void onCallStateChanged(int state, String incomingNumber){
        if (state == 1) {
            String msg = " New Phone Call Event. Incomming Number : "+incomingNumber;
            number=incomingNumber;
            sendSms();
            try {
                endCall();
            } catch (Exception e) {
                System.out.println(e.toString());
            }
            System.out.println("message sent");
            //add massage sendign code
        }
    }

    public void sendSms(){
        if (smsSend==false) {
            SmsManager m = SmsManager.getDefault();
            m.sendTextMessage(number, null, "I'm in a meeting.", null, null);
            smsSend=true;
        }
    }
    public void endCall() throws Exception {
        TelephonyManager telephonyManager=(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        Class clazz = Class.forName(telephonyManager.getClass().getName());
        Method method = clazz.getDeclaredMethod("getITelephony");
        method.setAccessible(true);


//        com.android.internal.telephony.ITelephony telephonyService = (ITelephony) method.invoke(telephonyManager);
//        telephonyService.endCall();
    }
}
