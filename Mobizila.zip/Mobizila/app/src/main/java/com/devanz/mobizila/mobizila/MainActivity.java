package com.devanz.mobizila.mobizila;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;


public class MainActivity extends ActionBarActivity {
    public BluetoothAdapter b;
    public TextView t1,t2;
    public int x;
    boolean silent,received;
    public String mod="normal";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t();
        System.out.println("oncreate");
        b = BluetoothAdapter.getDefaultAdapter();
        turnOnBluetooth(null);
        outOfMeeting();
    }

    public void turnOnBluetooth(View v){

        if (!b.isEnabled()) {
            b.enable();
        }
    }

    public void t(){
        Thread t=new Thread(){
            @Override
            public void run() {
                while(true) {
                    try {
                        discoverBt(null);
                        if (mod.equals("silent")){
                            x++;
                            if (x>3){
                                normal();
                                outOfMeeting();
                                x=0;
                            }
                        }
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        t.start();

    }

    public void inMeeting(){

        t1.setText("CONFERANCE ROOM");
        t2.setText("SILENT MODE : ON");

    }
    public  void outOfMeeting(){
         t1=(TextView)findViewById(R.id.place);
         t2=(TextView)findViewById(R.id.textView4);
        t1.setText("UNKNOWN LOCATION");
        t2.setText("SILENT MODE : OFF");

    }
    public void discoverBt(View v){
        if(b.isEnabled()) {
            IntentFilter in = new IntentFilter();
            in.addAction(BluetoothDevice.ACTION_FOUND);
            BroadcastReceiver bd = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    if (BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) {
                        BluetoothDevice btd = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        if (btd.getName().equals("Meeting")) {
                            if (mod.equals("normal")){

                                silent();
                                inMeeting();
                            }
                            x=0;
                        }

                    }
                }
            };
            registerReceiver(bd, in);
            b.startDiscovery();

            try {
                Thread.sleep(5000);
                b.cancelDiscovery();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }



    public void silent(){
        mod="silent";
        final AudioManager mobilemode = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        mobilemode.setRingerMode(AudioManager.RINGER_MODE_SILENT);
    }
    public void normal(){
        mod="normal";
        final AudioManager mobilemode = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        mobilemode.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        t1.setText("UNKNOWN LOCATION");
        t2.setText("SILENT MODE : OFF");
    }
    @Override
    protected void onDestroy() {
        b.disable();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
