package com.devanz.mobizila.mobizila;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.devanz.mobizila.config.MyPhoneStateListener;

/**
 * Created by Stelan Briyan on 5/12/2016.
 */
public class IncomingCall extends BroadcastReceiver{


    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            TelephonyManager tmgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            MyPhoneStateListener PhoneListener = new MyPhoneStateListener();
            PhoneListener.setContext(context);
            tmgr.listen(PhoneListener, PhoneStateListener.LISTEN_CALL_STATE);
        }catch (Exception e){

        }
    }


}
